package ml.ex;

public class Main {

	public static void main(String[] args) {
		Child obj=new Child();
		obj.display();
		System.out.println(obj.a);

	}

}
