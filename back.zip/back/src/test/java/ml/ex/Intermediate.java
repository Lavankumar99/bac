package ml.ex;

public class Intermediate extends Parent {

}
