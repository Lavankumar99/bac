package ml.ex;

public class Child extends Intermediate  {

	public static void main(String[] args) {
	

	}

}
